
"""LunarReg Phase 13 — controlled angle/footprint diagnostic.

Research-only. Does not modify production code.

The script intentionally uses the existing Phase 7 and Phase 9 research
implementations. It inspects signatures/configuration fields so that a
compact-footprint Phase 9 condition is never simulated or silently substituted.
"""

from __future__ import annotations

import argparse
import dataclasses
import inspect
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import cv2
import numpy as np
import pandas as pd


SEEDS = (1, 2, 3, 4, 5)
RANSAC_THRESH = 3.0

FOOTPRINTS = {
    "baseline_7x7_r4": (7, 4.0),
    "compact_5x5_r3": (5, 3.0),
}

ROTATIONS = (10.0, 20.0, 30.0, -20.0)


def _set_config_value(cfg: Any, aliases: Iterable[str], value: Any) -> bool:
    """Set an existing config field/attribute using explicit aliases only."""
    for name in aliases:
        if hasattr(cfg, name):
            setattr(cfg, name, value)
            return True
    return False


def _clone_config(cls: Any, patch_size: int, radius: float) -> Any:
    cfg = cls()
    # SSC implementations observed in LunarReg use patch_size/radius.
    patch_ok = _set_config_value(cfg, ("patch_size", "ssc_patch_size"), patch_size)
    radius_ok = _set_config_value(cfg, ("radius", "ssc_radius"), radius)
    if not patch_ok or not radius_ok:
        raise RuntimeError(
            f"{cls.__name__} does not expose a controlled patch_size/radius configuration. "
            "Phase 13 will not silently modify implementation code."
        )
    return cfg


def _run_with_optional_kwargs(fn, source, reference, config):
    """Call an existing matcher using only arguments present in its signature."""
    sig = inspect.signature(fn)
    kwargs = {}
    names = sig.parameters

    if "source_img" in names:
        kwargs["source_img"] = source
    elif "source" in names:
        kwargs["source"] = source
    else:
        raise RuntimeError(f"{fn.__name__} has no recognized source-image parameter.")

    if "reference_img" in names:
        kwargs["reference_img"] = reference
    elif "reference" in names:
        kwargs["reference"] = reference
    else:
        raise RuntimeError(f"{fn.__name__} has no recognized reference-image parameter.")

    if "config" in names:
        kwargs["config"] = config
    if "ransac_thresh" in names:
        kwargs["ransac_thresh"] = RANSAC_THRESH
    if "seeds" in names:
        kwargs["seeds"] = SEEDS
    if "pair_label" in names:
        kwargs["pair_label"] = "phase13"

    return fn(**kwargs)


def _normalize_result(res: Dict[str, Any], label: str) -> Dict[str, Any]:
    down = res.get("downstream_result") or res.get("downstream") or {}
    candidates = int(
        res.get("candidates", res.get("n_candidates", down.get("n_candidates", 0))) or 0
    )
    initial_inliers = int(
        res.get(
            "initial_inliers",
            res.get(
                "n_inliers",
                down.get("n_initial_inliers", down.get("n_final_inliers", 0)),
            ),
        )
        or 0
    )
    ratio = float(
        res.get(
            "initial_inlier_ratio",
            (initial_inliers / candidates) if candidates else 0.0,
        )
        or 0.0
    )
    occ = float(res.get("spatial_occupancy", down.get("spatial_occupancy", 0.0)) or 0.0)
    fit = res.get("fit_rmse", down.get("fit_rmse"))
    held = res.get(
        "independent_held_out_rmse",
        res.get("heldout_rmse", down.get("mean_check_rmse")),
    )
    valid = bool(
        res.get(
            "success",
            res.get("held_out_valid", down.get("held_out_valid", False)),
        )
    )
    return {
        "label": label,
        "candidates": candidates,
        "initial_inliers": initial_inliers,
        "initial_inlier_ratio": round(ratio, 4),
        "spatial_occupancy": round(occ, 4),
        "fit_rmse": None if fit is None else float(fit),
        "heldout_rmse": None if held is None else float(held),
        "heldout_valid": valid and held is not None,
        "failure_stage": res.get("failure_stage", down.get("failure_stage")),
        "failure_reason": res.get("failure_reason", down.get("failure_reason")),
    }


def _load_pair(base_dir: Path, pair_id: str):
    p = base_dir / pair_id
    src = next((p / f"source{ext}" for ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff") if (p / f"source{ext}").exists()), None)
    ref = next((p / f"reference{ext}" for ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff") if (p / f"reference{ext}").exists()), None)
    if src is None or ref is None:
        raise FileNotFoundError(f"Missing source/reference files in {p}")
    s = cv2.imread(str(src))
    r = cv2.imread(str(ref))
    if s is None or r is None:
        raise RuntimeError(f"Failed to decode {pair_id}")
    return s, r


def _rotate_source(img: np.ndarray, degrees: float) -> np.ndarray:
    h, w = img.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), degrees, 1.0)
    return cv2.warpAffine(
        img,
        m,
        (w, h),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT,
    )


def build_runner():
    try:
        from research.multimodal.ssc_matcher import SSCConfig, run_ssc_matching
    except Exception as exc:
        raise RuntimeError(f"Phase 7 import failed: {exc}") from exc

    phase9_import_error = None
    try:
        from research.multimodal.ssc_rotation import SSCRotationConfig, run_ssc_rotation_matching
    except Exception as exc:
        phase9_import_error = str(exc)
        SSCRotationConfig = None
        run_ssc_rotation_matching = None

    if SSCRotationConfig is None or run_ssc_rotation_matching is None:
        raise RuntimeError(
            "Phase 9 rotation-normalized SSC implementation could not be imported: "
            + str(phase9_import_error)
        )

    return (SSCConfig, run_ssc_matching, SSCRotationConfig, run_ssc_rotation_matching)


def run_phase13(iirs_source: str, ohrc_reference: str, angle_base: Optional[str], output_dir: Path):
    SSCConfig, run_p7, P9Config, run_p9 = build_runner()

    source = cv2.imread(iirs_source)
    reference = cv2.imread(ohrc_reference)
    if source is None or reference is None:
        raise FileNotFoundError("Primary IIRS/OHRC images could not be decoded.")

    angle_root = Path(angle_base) if angle_base else (
        Path(__file__).resolve().parents[2] / "data" / "research" / "phase3_rift2" / "angle_pairs"
    )

    # Lock a pre-declared list of datasets.
    cases = [("native_iirs_ohrc", source, reference)]
    for deg in ROTATIONS:
        cases.append((f"synthetic_rotation_{deg:+g}", _rotate_source(source, deg), reference))

    for pid in ("pair_01", "pair_02", "pair_03"):
        if (angle_root / pid).exists():
            cases.append((pid, *_load_pair(angle_root, pid)))

    rows: List[Dict[str, Any]] = []

    for fp_name, (patch_size, radius) in FOOTPRINTS.items():
        p7_cfg = _clone_config(SSCConfig, patch_size, radius)
        p9_cfg = _clone_config(P9Config, patch_size, radius)

        for case_name, s_img, r_img in cases:
            for method, fn, cfg in (
                ("Phase 7 SSC", run_p7, p7_cfg),
                ("Phase 9 Rot-Norm SSC", run_p9, p9_cfg),
            ):
                t0 = time.perf_counter()
                try:
                    res = _run_with_optional_kwargs(fn, s_img, r_img, cfg)
                    rec = _normalize_result(
                        res,
                        f"{case_name} | {method} | {fp_name}",
                    )
                    rec["case"] = case_name
                    rec["method"] = method
                    rec["footprint"] = fp_name
                    rec["patch_size"] = patch_size
                    rec["radius"] = radius
                    rec["runtime_sec"] = round(time.perf_counter() - t0, 3)
                    rows.append(rec)
                except Exception as exc:
                    rows.append({
                        "case": case_name,
                        "method": method,
                        "footprint": fp_name,
                        "patch_size": patch_size,
                        "radius": radius,
                        "candidates": 0,
                        "initial_inliers": 0,
                        "initial_inlier_ratio": 0.0,
                        "spatial_occupancy": 0.0,
                        "fit_rmse": None,
                        "heldout_rmse": None,
                        "heldout_valid": False,
                        "failure_stage": "execution",
                        "failure_reason": str(exc),
                        "runtime_sec": round(time.perf_counter() - t0, 3),
                    })

    df = pd.DataFrame(rows)
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "phase13_angle_footprint_results.csv"
    df.to_csv(csv_path, index=False)

    design = {
        "phase": 13,
        "question": "Does the compact local footprint preserve or improve angle-robustness behavior of rotation-normalized SSC?",
        "footprints": {k: {"patch_size": v[0], "radius": v[1]} for k, v in FOOTPRINTS.items()},
        "synthetic_rotations_deg": list(ROTATIONS),
        "real_controls": ["pair_01", "pair_02", "pair_03"],
        "production_modified": False,
        "automatic_winner_selection": False,
    }
    (output_dir / "phase13_design.json").write_text(json.dumps(design, indent=2), encoding="utf-8")

    lines = [
        "# LunarReg Phase 13 — Angle/Footprint Transfer Diagnostic",
        "",
        "## Purpose",
        "Evaluate whether the compact 5×5/R3 local footprint changes the angle-robustness behavior of Phase 9 rotation-normalized SSC relative to the frozen Phase 7 baseline.",
        "",
        "## Interpretation boundary",
        "No footprint is automatically selected or promoted. Held-out validation is required before treating an end-to-end run as a validated registration result.",
        "",
        "## Results",
        "",
        df.to_markdown(index=False),
        "",
        "## Production boundary",
        "No production routing, quality gate, Locked LoFTR, RANSAC mathematics, or common downstream implementation was modified by this benchmark.",
    ]
    (output_dir / "phase13_angle_footprint_report.md").write_text("\n".join(lines), encoding="utf-8")
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--iirs-source", required=True)
    parser.add_argument("--ohrc-reference", required=True)
    parser.add_argument("--angle-pairs-base", default=None)
    args = parser.parse_args()

    out = Path("research") / "multimodal" / "phase13_results"
    df = run_phase13(
        args.iirs_source,
        args.ohrc_reference,
        args.angle_pairs_base,
        out,
    )
    print(
        f"Phase 13 complete. Cases={df['case'].nunique()} "
        f"footprints={df['footprint'].nunique()} methods={df['method'].nunique()} "
        f"output={out}"
    )
    print("Diagnosis is intentionally left for evidence review; no automatic winner or production decision was applied.")


if __name__ == "__main__":
    main()
